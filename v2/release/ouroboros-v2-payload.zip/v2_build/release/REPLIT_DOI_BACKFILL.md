# Replit Follow-Up — DOI Backfill

Paste this into Replit chat. Do this AFTER the v2-empirical-companion PR is merged to main.

---

**Task:** Backfill the Zenodo v2 DOI now that it's been minted, then cut the GitHub release.

**Zenodo v2 DOI (real, just minted):** `10.5281/zenodo.19934129`
**Zenodo v2 URL:** https://doi.org/10.5281/zenodo.19934129
**Repo:** `szl-holdings/ouroboros-thesis` on `main`

**Step 1 — Backfill commit:**

Pull main. Across these files, replace every `10.5281/zenodo.XXXXXXXX` with `10.5281/zenodo.19934129` (and any bare `XXXXXXXX` in the same context):

- `README.md` (root)
- `CITATION.cff` (root)
- `v2/release/RELEASE_NOTES.md`
- `v2/blog/companion-post.md`
- `v2/submission/zenodo-metadata.json` (only if the placeholder still exists there — it shouldn't)

The Replit workspace at `/home/user/workspace/v2_build/` has the already-backfilled versions of each file you can copy from if useful, but a sed replace is fine:

```bash
# from the repo root, on main:
git pull
grep -rln "zenodo.XXXXXXXX" . | xargs sed -i 's/zenodo\.XXXXXXXX/zenodo.19934129/g'
git diff --stat
```

Verify the diff looks right (only DOI lines changed). Commit:

```
chore(v2): backfill Zenodo DOI 10.5281/zenodo.19934129

v2 published on Zenodo as a "New version" of v1 (10.5281/zenodo.19867281).
Concept DOI 10.5281/zenodo.19867281 now resolves to v2 as the latest version.
```

Push to main.

**Step 2 — Cut the GitHub release v2.0.0:**

```bash
git tag -a v2.0.0 -m "v2.0.0 — The Loop Is the Product (empirical companion)"
git push origin v2.0.0

gh release create v2.0.0 \
  --title "v2.0.0 — The Loop Is the Product" \
  --notes-file v2/release/RELEASE_NOTES.md \
  --latest \
  v2/paper/ouroboros-thesis-v2-empirical.pdf
```

If you also have the bundled zip (`ouroboros-v2-payload.zip`) in the workspace, attach it too:

```bash
gh release upload v2.0.0 /path/to/ouroboros-v2-payload.zip
```

**Step 3 — Verify:**

- [ ] https://github.com/szl-holdings/ouroboros-thesis/releases/tag/v2.0.0 loads
- [ ] PDF opens when clicked
- [ ] Release notes render with the live Zenodo DOI (https://doi.org/10.5281/zenodo.19934129)
- [ ] Repo home shows "Cite this repository" button — clicking it shows the v2 bibtex
- [ ] Repo "About" sidebar shows the badges: 142/142 tests, v2.0.0 paper, Zenodo DOI

**Report back:** the release URL and commit SHA of the backfill. That's it.

---

## What NOT to do

- Do NOT touch the proprietary runtime repo `szl-holdings/ouroboros`.
- Do NOT modify `ouroboros-thesis-v2.md` (the v1 text), `papers/ouroboros-thesis-v3.md`, or any pre-existing v1 artifacts.
- Do NOT mark the release as pre-release. Mark `--latest`.
