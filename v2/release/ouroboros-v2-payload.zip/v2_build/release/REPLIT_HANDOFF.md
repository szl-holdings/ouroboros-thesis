# Replit Handoff Prompt — paste this into Replit chat

Copy everything between the `---` lines below and paste into Replit. The prompt is structured so the agent does all the right things and none of the wrong ones.

---

**Task:** Add the v2 empirical companion paper bundle to the public GitHub repo `szl-holdings/ouroboros-thesis`. Open a PR. Do NOT cut a release yet — that's a manual step after Zenodo mints the DOI.

**Important context:**
- The repo already has v1 content at the root (`ouroboros-thesis-v2.md` is the v1 *position paper text*, despite the filename — it's what's published on Zenodo as record 19867281).
- There's also a `papers/ouroboros-thesis-v3.md` from prior internal work. Do NOT delete or modify it — it's superseded by the new empirical companion but kept for record.
- The new v2 empirical companion is the formal published v2 and goes in a new top-level `v2/` folder.
- The proprietary runtime repo `szl-holdings/ouroboros` is **off-limits** for this task. Only touch `szl-holdings/ouroboros-thesis`.

**Inputs (in this Replit workspace at `/home/user/workspace/v2_build/`):**
- `paper/` — the new empirical companion paper (markdown + PDF + CSS)
- `experiments/` — MIT-licensed replication harness
- `study/` — pre-registered protocol
- `blog/companion-post.md` — companion announcement post
- `submission/` — Zenodo + arXiv playbooks
- `release/` — release notes, GitHub release playbook, this Replit handoff, the new README to use, and a CITATION.cff template
- `PAYLOAD.md` — index of the whole bundle

**Steps:**

1. Clone `https://github.com/szl-holdings/ouroboros-thesis` into a fresh directory. Use the existing GitHub auth available in this workspace.

2. Create a branch named `v2-empirical-companion`.

3. Copy the entire contents of `/home/user/workspace/v2_build/` into a new folder at the repo root called `v2/`. Final layout should be:
   ```
   /                              ← v1 content stays untouched
   /ouroboros-thesis-v2.md        ← v1 position paper (DO NOT EDIT)
   /papers/ouroboros-thesis-v3.md ← prior internal v3 (DO NOT EDIT)
   /v2/                           ← new empirical companion
       paper/
       experiments/
       study/
       blog/
       submission/
       release/
       PAYLOAD.md
   ```

4. Replace the repo root `README.md` with the contents of `v2/release/REPO_README_UPDATE.md`. Keep the placeholder `XXXXXXXX` in the DOI fields — those get filled in after Zenodo publishing.

5. Create a new file `CITATION.cff` at the repo root. Use this content exactly:
   ```yaml
   cff-version: 1.2.0
   message: "If you use this work, please cite it as below."
   title: "The Loop Is the Product: Measuring Bounded Recursion as a System Primitive for Auditable AI"
   authors:
     - family-names: Lutar
       given-names: Stephen P.
       affiliation: SZL Holdings
   date-released: 2026-04-30
   version: 2.0.0
   doi: 10.5281/zenodo.19934129
   url: https://github.com/szl-holdings/ouroboros-thesis
   license: CC-BY-4.0
   type: article
   identifiers:
     - type: doi
       value: 10.5281/zenodo.19867281
       description: v1 position paper (predecessor)
   keywords:
     - adaptive computation
     - recursive systems
     - AI governance
     - auditable AI
     - decision receipts
     - reproducibility
   ```

6. Commit with this exact message:
   ```
   feat(v2): empirical companion paper + harness + study + submission kit

   Adds the formal v2 empirical companion to the v1 position paper:
   - 20-page typeset paper (CC BY 4.0) with §3.7 falsification ledger
     and §10 reproducibility manifest pinning real commit and blob SHAs
   - MIT-licensed replication harness (Pareto extractor, frontier sweep)
   - Pre-registered audit study protocol with deterministic randomization
   - Companion blog post, Zenodo + arXiv playbooks, GitHub release plan
   - Updated root README with v2 routing and CITATION.cff for the
     "Cite this repository" button

   Companion to v1 (Zenodo: 10.5281/zenodo.19867281). DOI placeholder
   (XXXXXXXX) will be replaced after Zenodo "New version" is published.
   ```

7. Push the branch to origin.

8. Open a Pull Request with:
   - **Title:** `v2: Empirical Companion to the Ouroboros Thesis`
   - **Body:**
     ```
     Adds the v2 empirical companion to the v1 position paper.

     - Paper, harness, study protocol, blog post, submission/release kits — see `v2/PAYLOAD.md` for the full index.
     - Root `README.md` updated with v2 routing.
     - `CITATION.cff` added so the "Cite this repository" button auto-renders.

     Companion to v1 (Zenodo: 10.5281/zenodo.19867281).

     **Do not cut a GitHub release from this PR.** The release is cut manually after Zenodo "New version" is published and the v2 DOI is minted, then `XXXXXXXX` placeholders in `README.md`, `CITATION.cff`, and `v2/release/RELEASE_NOTES.md` get replaced in a follow-up commit.

     Follow `v2/release/GITHUB_RELEASE_PLAYBOOK.md` for the release-cut step after merge.
     ```

9. Report back the PR URL and the branch name. Do NOT merge it yourself — leave the merge for manual review.

**What NOT to do:**
- Do NOT touch `ouroboros-thesis-v2.md` (v1 text), `ouroboros-thesis-v2.docx`, `ouroboros-runtime-contract.v2.json`, `a11oy-ultimate-replit-payload.v6.json`, or `papers/ouroboros-thesis-v3.md`.
- Do NOT push to `main` directly.
- Do NOT cut a release tag.
- Do NOT touch the runtime repo `szl-holdings/ouroboros`.
- Do NOT replace the `XXXXXXXX` DOI placeholders — that's a follow-up commit after Zenodo publish.
- Do NOT include any `node_modules/`, `dist/`, or `.env` files. If `v2_build/experiments/` has them, exclude them from the copy.

---

## After this Replit task succeeds

1. Review the PR on GitHub.
2. Merge it (or ask Replit to merge after your approval).
3. Go publish on Zenodo following `v2/submission/ZENODO_PLAYBOOK.md`.
4. Once Zenodo mints your v2 DOI, send Replit a follow-up:

   > **Follow-up:** the Zenodo v2 DOI is `10.5281/zenodo.19934129`. On `main`, do a search-and-replace of `XXXXXXXX` with `19934129` across `README.md`, `CITATION.cff`, `v2/release/RELEASE_NOTES.md`, `v2/blog/companion-post.md`, and `v2/submission/zenodo-metadata.json`. Commit message: `chore(v2): backfill Zenodo DOI 10.5281/zenodo.19934129`. Push to main.

5. Then cut the GitHub release v2.0.0 manually following `v2/release/GITHUB_RELEASE_PLAYBOOK.md`.
